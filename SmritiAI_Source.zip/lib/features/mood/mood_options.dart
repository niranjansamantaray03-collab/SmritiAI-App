class MoodOption {
  final String id;
  final String label;
  final String emoji;

  const MoodOption({
    required this.id,
    required this.label,
    required this.emoji,
  });
}

class MoodOptions {
  static const options = [
    MoodOption(
      id: 'very_happy',
      label: 'Very Happy',
      emoji: '😁',
    ),
    MoodOption(
      id: 'happy',
      label: 'Happy',
      emoji: '🙂',
    ),
    MoodOption(
      id: 'okay',
      label: 'Okay',
      emoji: '😐',
    ),
    MoodOption(
      id: 'sad',
      label: 'Sad',
      emoji: '😔',
    ),
    MoodOption(
      id: 'very_sad',
      label: 'Very Sad',
      emoji: '😢',
    ),
  ];
}
