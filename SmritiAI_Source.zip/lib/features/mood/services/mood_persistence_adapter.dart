
import '../../../data/persistence/feature_write_service.dart';
import '../mood_entry.dart';

class MoodPersistenceAdapter {
  MoodPersistenceAdapter._();

  static final MoodPersistenceAdapter instance =
      MoodPersistenceAdapter._();

  Future<void> save(MoodEntry entry) {
    return FeatureWriteService.instance.saveMood(entry);
  }
}
