import 'package:flutter/material.dart';

import '../services/mood_service.dart';

class CaregiverMoodScreen extends StatelessWidget {
  final String patientId;
  final String patientName;

  const CaregiverMoodScreen({
    super.key,
    required this.patientId,
    required this.patientName,
  });

  @override
  Widget build(BuildContext context) {
    final entries =
        MoodService.instance.getEntries(patientId);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Mood History'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          Text(
            'Mood of $patientName',
            style: const TextStyle(
              fontSize: 26,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 18),

          if (entries.isEmpty)
            const Card(
              child: Padding(
                padding: EdgeInsets.all(20),
                child: Text(
                  'No mood entries recorded yet.',
                  style: TextStyle(fontSize: 18),
                ),
              ),
            )
          else
            ...entries.map(
              (entry) => Card(
                margin: const EdgeInsets.only(bottom: 10),
                child: ListTile(
                  leading: const CircleAvatar(
                    child: Icon(Icons.mood),
                  ),
                  title: Text(
                    entry.mood,
                    style: const TextStyle(
                      fontSize: 19,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  subtitle: Text(
                    entry.note.isEmpty
                        ? 'No note'
                        : entry.note,
                  ),
                  trailing: Text(
                    '${entry.createdAt.day}/'
                    '${entry.createdAt.month}/'
                    '${entry.createdAt.year}',
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}
