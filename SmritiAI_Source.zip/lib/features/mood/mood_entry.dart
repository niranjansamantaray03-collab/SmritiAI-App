class MoodEntry {
  final String id;
  final String patientId;
  final DateTime createdAt;
  final String mood;
  final String? note;

  const MoodEntry({
    required this.id,
    required this.patientId,
    required this.createdAt,
    required this.mood,
    this.note,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'patientId': patientId,
      'createdAt': createdAt.toIso8601String(),
      'mood': mood,
      'note': note,
    };
  }
}
