
import 'package:flutter_local_notifications/flutter_local_notifications.dart';

import '../../core/device/smriti_device_actions.dart';

class ReminderNotificationBridge {
  ReminderNotificationBridge._();

  static final ReminderNotificationBridge instance =
      ReminderNotificationBridge._();

  int notificationId(String reminderId) {
    return reminderId.hashCode.abs() % 2000000000;
  }

  Future<void> requestPermission() {
    return SmritiDeviceActions.instance
        .requestNotificationPermission();
  }

  Future<void> schedule({
    required String reminderId,
    required String title,
    required String body,
    required DateTime scheduledAt,
  }) {
    return SmritiDeviceActions.instance.scheduleReminder(
      id: notificationId(reminderId),
      title: title,
      body: body,
      scheduledAt: scheduledAt,
    );
  }

  Future<void> cancel(String reminderId) {
    return SmritiDeviceActions.instance.cancelReminder(
      notificationId(reminderId),
    );
  }
}
