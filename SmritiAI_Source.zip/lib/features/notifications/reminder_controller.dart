
import 'package:flutter/foundation.dart';

import 'reminder.dart';
import 'reminder_service.dart';

class ReminderController
    extends ChangeNotifier {
  ReminderController({
    required this.patientId,
  });

  final String patientId;

  List<SmritiReminder> reminders = [];

  bool loading = false;

  Future<void> load() async {
    loading = true;
    notifyListeners();

    reminders =
        await ReminderService.instance
            .getForPatient(
      patientId,
    );

    loading = false;
    notifyListeners();
  }

  Future<void> disable(
    String reminderId,
  ) async {
    await ReminderService.instance
        .disable(reminderId);

    await load();
  }

  Future<void> enable(
    String reminderId,
  ) async {
    await ReminderService.instance
        .enable(reminderId);

    await load();
  }

  Future<void> delete(
    String reminderId,
  ) async {
    await ReminderService.instance
        .delete(reminderId);

    await load();
  }
}
