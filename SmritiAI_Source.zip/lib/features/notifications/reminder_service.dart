
import 'reminder.dart';
import '../../services/notification_service.dart';
import '../../core/auth/user_context.dart';
import '../../data/persistence/persistence_manager.dart';
import '../../data/sync/sync_manager.dart';

class ReminderService {
  ReminderService._();

  static final ReminderService instance =
      ReminderService._();

  final Map<String, SmritiReminder>
      _reminders = {};

  bool _loaded = false;

  Future<void> initialize() async {
    if (_loaded) return;

    final records =
        await PersistenceManager.instance
            .getAll('reminders');

    for (final record in records) {
      try {
        final reminder =
            SmritiReminder.fromMap(record);

        _reminders[reminder.id] =
            reminder;
      } catch (_) {}
    }

    _loaded = true;
  }

  Future<List<SmritiReminder>>
      getForPatient(
    String patientId,
  ) async {
    await initialize();

    return _reminders.values
        .where(
          (item) =>
              item.patientId ==
              patientId,
        )
        .where(
          (item) => item.enabled,
        )
        .toList()
      ..sort(
        (a, b) => a.scheduledAt
            .compareTo(b.scheduledAt),
      );
  }

  Future<SmritiReminder> create({
    required String patientId,
    required String caregiverId,
    required String title,
    required String description,
    required DateTime scheduledAt,
    ReminderRepeat repeat =
        ReminderRepeat.once,
    ReminderKind kind =
        ReminderKind.custom,
  }) async {
    await initialize();

    final id =
        'rem_${DateTime.now().microsecondsSinceEpoch}';

    final reminder = SmritiReminder(
      id: id,
      patientId: patientId,
      caregiverId: caregiverId,
      title: title,
      description: description,
      scheduledAt: scheduledAt,
      repeat: repeat,
      kind: kind,
      createdAt: DateTime.now(),
    );

    _reminders[id] = reminder;

    await _save(reminder);
    await schedule(reminder);

    return reminder;
  }

  Future<void> update(
    SmritiReminder reminder,
  ) async {
    await initialize();

    _reminders[reminder.id] =
        reminder;

    await _save(reminder);

    await NotificationService.instance
        .cancel(
      NotificationService.instance
          .stableNotificationId(
        reminder.id,
      ),
    );

    if (reminder.enabled) {
      await schedule(reminder);
    }
  }

  Future<void> enable(
    String id,
  ) async {
    final reminder = _reminders[id];

    if (reminder == null) return;

    await update(
      reminder.copyWith(
        enabled: true,
      ),
    );
  }

  Future<void> disable(
    String id,
  ) async {
    final reminder = _reminders[id];

    if (reminder == null) return;

    final disabled =
        reminder.copyWith(
      enabled: false,
    );

    _reminders[id] = disabled;

    await _save(disabled);

    await NotificationService.instance
        .cancel(
      NotificationService.instance
          .stableNotificationId(id),
    );
  }

  Future<void> delete(
    String id,
  ) async {
    _reminders.remove(id);

    await PersistenceManager.instance
        .delete(
      'reminders',
      id,
    );

    await NotificationService.instance
        .cancel(
      NotificationService.instance
          .stableNotificationId(id),
    );

    SyncManager.instance.queueRecord(
      collection: 'reminders',
      patientId:
          UserContext.patientIdForCurrentUser ??
              '',
      operation: 'delete',
      data: {
        'id': id,
        'deleted': true,
      },
    );
  }

  Future<void> schedule(
    SmritiReminder reminder,
  ) async {
    if (!reminder.enabled) return;

    final request =
        NotificationRequest(
      id:
          NotificationService.instance
              .stableNotificationId(
        reminder.id,
      ),
      title: reminder.title,
      body: reminder.description,
      scheduledAt:
          _nextValidDate(
        reminder,
      ),
      recurring:
          reminder.repeat !=
              ReminderRepeat.once,
      payload:
          'smritiai://reminder/${reminder.id}',
    );

    await NotificationService.instance
        .schedule(request);
  }

  DateTime _nextValidDate(
    SmritiReminder reminder,
  ) {
    var date =
        reminder.scheduledAt;

    final now = DateTime.now();

    if (reminder.repeat ==
        ReminderRepeat.once) {
      return date;
    }

    while (date.isBefore(now)) {
      if (reminder.repeat ==
          ReminderRepeat.daily) {
        date =
            date.add(
          const Duration(days: 1),
        );
      } else {
        date =
            date.add(
          const Duration(days: 7),
        );
      }
    }

    return date;
  }

  Future<void> _save(
    SmritiReminder reminder,
  ) async {
    await PersistenceManager.instance
        .save(
      'reminders',
      reminder.id,
      reminder.toMap(),
    );

    SyncManager.instance.queueRecord(
      collection: 'reminders',
      patientId:
          reminder.patientId,
      operation: 'upsert',
      data: reminder.toMap(),
    );
  }
}
