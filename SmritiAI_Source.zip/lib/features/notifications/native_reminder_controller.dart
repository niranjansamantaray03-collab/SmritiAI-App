import 'package:flutter/foundation.dart';

import '../../core/native/smriti_native_services.dart';
import 'reminder.dart';

class NativeReminderController {
  NativeReminderController._();

  static final NativeReminderController instance =
      NativeReminderController._();

  int notificationId(String reminderId) {
    var hash = 0;
    for (final c in reminderId.codeUnits) {
      hash = ((hash << 5) - hash + c) & 0x7fffffff;
    }
    return hash == 0 ? 1 : hash;
  }

  Future<void> schedule(SmritiReminder reminder) async {
    if (!reminder.enabled) return;

    final date = reminder.scheduledAt;
    if (date == null) return;
    if (date.isBefore(DateTime.now())) return;

    try {
      await SmritiNativeServices.notifications.schedule(
        id: notificationId(reminder.id),
        title: reminder.title,
        body: reminder.description.isEmpty
            ? 'This is a SmritiAI reminder.'
            : reminder.description,
        dateTime: date,
      );
    } catch (e) {
      debugPrint('Reminder scheduling failed: $e');
    }
  }

  Future<void> cancel(SmritiReminder reminder) async {
    await SmritiNativeServices.notifications.cancel(
      notificationId(reminder.id),
    );
  }
}
