
enum ReminderRepeat {
  once,
  daily,
  weekly,
}

enum ReminderKind {
  medication,
  task,
  appointment,
  hydration,
  meal,
  exercise,
  rudas,
  custom,
}

class SmritiReminder {
  final String id;
  final String patientId;
  final String caregiverId;
  final String title;
  final String description;
  final DateTime scheduledAt;
  final ReminderRepeat repeat;
  final ReminderKind kind;
  final bool enabled;
  final DateTime createdAt;
  final DateTime? updatedAt;

  const SmritiReminder({
    required this.id,
    required this.patientId,
    required this.caregiverId,
    required this.title,
    required this.description,
    required this.scheduledAt,
    required this.repeat,
    required this.kind,
    this.enabled = true,
    required this.createdAt,
    this.updatedAt,
  });

  SmritiReminder copyWith({
    String? title,
    String? description,
    DateTime? scheduledAt,
    ReminderRepeat? repeat,
    ReminderKind? kind,
    bool? enabled,
    DateTime? updatedAt,
  }) {
    return SmritiReminder(
      id: id,
      patientId: patientId,
      caregiverId: caregiverId,
      title: title ?? this.title,
      description: description ?? this.description,
      scheduledAt: scheduledAt ?? this.scheduledAt,
      repeat: repeat ?? this.repeat,
      kind: kind ?? this.kind,
      enabled: enabled ?? this.enabled,
      createdAt: createdAt,
      updatedAt: updatedAt ?? DateTime.now(),
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'patient_id': patientId,
      'caregiver_id': caregiverId,
      'title': title,
      'description': description,
      'scheduled_at': scheduledAt.toIso8601String(),
      'repeat': repeat.name,
      'kind': kind.name,
      'enabled': enabled,
      'created_at': createdAt.toIso8601String(),
      'updated_at': updatedAt?.toIso8601String(),
    };
  }

  factory SmritiReminder.fromMap(
    Map<String, dynamic> map,
  ) {
    return SmritiReminder(
      id: map['id'] as String,
      patientId:
          map['patient_id'] as String? ?? '',
      caregiverId:
          map['caregiver_id'] as String? ?? '',
      title:
          map['title'] as String? ?? '',
      description:
          map['description'] as String? ?? '',
      scheduledAt:
          DateTime.tryParse(
                map['scheduled_at'] as String? ?? '',
              ) ??
              DateTime.now(),
      repeat: ReminderRepeat.values.firstWhere(
        (value) =>
            value.name ==
            (map['repeat'] as String? ?? 'once'),
        orElse: () => ReminderRepeat.once,
      ),
      kind: ReminderKind.values.firstWhere(
        (value) =>
            value.name ==
            (map['kind'] as String? ?? 'custom'),
        orElse: () => ReminderKind.custom,
      ),
      enabled:
          map['enabled'] as bool? ?? true,
      createdAt:
          DateTime.tryParse(
                map['created_at'] as String? ?? '',
              ) ??
              DateTime.now(),
      updatedAt:
          DateTime.tryParse(
            map['updated_at'] as String? ?? '',
          ),
    );
  }
}
