import 'package:flutter/material.dart';

import '../../../core/native/smriti_native_services.dart';

class DeviceFeaturesScreen extends StatelessWidget {
  const DeviceFeaturesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Voice & device features'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          _FeatureCard(
            icon: Icons.volume_up_rounded,
            title: 'Voice guidance',
            subtitle: 'SmritiAI can read instructions aloud.',
            action: FilledButton(
              onPressed: () {
                SmritiNativeServices.voice.speak(
                  'Hello. SmritiAI is ready to help you.',
                  locale: 'en-IN',
                );
              },
              child: const Text('Test voice'),
            ),
          ),
          _FeatureCard(
            icon: Icons.mic_rounded,
            title: 'Speech recognition',
            subtitle: 'Use your voice for supported memory activities.',
            action: FilledButton(
              onPressed: () async {
                final ok =
                    await SmritiNativeServices.speech.initialize();

                if (!context.mounted) return;

                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text(
                      ok
                          ? 'Speech recognition is ready.'
                          : 'Speech recognition is unavailable.',
                    ),
                  ),
                );
              },
              child: const Text('Test microphone'),
            ),
          ),
          _FeatureCard(
            icon: Icons.notifications_active_rounded,
            title: 'Notifications',
            subtitle: 'Receive caregiver tasks and reminders.',
            action: FilledButton(
              onPressed: () {
                SmritiNativeServices.notifications.showNow(
                  id: 999991,
                  title: 'SmritiAI',
                  body: 'Your notification system is working.',
                );
              },
              child: const Text('Test notification'),
            ),
          ),
        ],
      ),
    );
  }
}

class _FeatureCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final Widget action;

  const _FeatureCard({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.action,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 18),
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(icon, size: 38),
            const SizedBox(height: 12),
            Text(
              title,
              style: const TextStyle(
                fontSize: 23,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              subtitle,
              style: const TextStyle(
                fontSize: 18,
                height: 1.4,
              ),
            ),
            const SizedBox(height: 16),
            action,
          ],
        ),
      ),
    );
  }
}
