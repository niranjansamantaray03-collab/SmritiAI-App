import 'package:flutter/material.dart';

import '../../../core/theme/smriti_theme.dart';
import '../../../core/native/smriti_native_services.dart';
import '../services/patient_welcome_controller.dart';

class NativeWelcomeScreen extends StatefulWidget {
  const NativeWelcomeScreen({super.key});

  @override
  State<NativeWelcomeScreen> createState() => _NativeWelcomeScreenState();
}

class _NativeWelcomeScreenState extends State<NativeWelcomeScreen> {
  @override
  void initState() {
    super.initState();
    Future.microtask(
      PatientWelcomeController.instance.start,
    );
  }

  @override
  void dispose() {
    PatientWelcomeController.instance.stop();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: SmritiTheme.background,
      body: SafeArea(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(28),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  width: 120,
                  height: 120,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: SmritiTheme.primary.withOpacity(.12),
                  ),
                  child: const Icon(
                    Icons.favorite_rounded,
                    size: 64,
                  ),
                ),
                const SizedBox(height: 28),
                const Text(
                  'Welcome to SmritiAI',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 30,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(height: 12),
                const Text(
                  'A calm and familiar space for memories, activities and daily care.',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 20,
                    height: 1.4,
                  ),
                ),
                const SizedBox(height: 36),
                FilledButton.icon(
                  style: FilledButton.styleFrom(
                    minimumSize: const Size.fromHeight(64),
                  ),
                  onPressed: () {
                    Navigator.pushReplacementNamed(
                      context,
                      '/patient',
                    );
                  },
                  icon: const Icon(Icons.home_rounded),
                  label: const Text(
                    'Continue',
                    style: TextStyle(fontSize: 22),
                  ),
                ),
                const SizedBox(height: 14),
                OutlinedButton.icon(
                  style: OutlinedButton.styleFrom(
                    minimumSize: const Size.fromHeight(60),
                  ),
                  onPressed: () {
                    SmritiNativeServices.music.stop();
                  },
                  icon: const Icon(Icons.music_off_rounded),
                  label: const Text(
                    'Stop music',
                    style: TextStyle(fontSize: 19),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
