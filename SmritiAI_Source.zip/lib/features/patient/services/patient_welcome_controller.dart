import 'package:flutter/foundation.dart';

import '../../../core/native/smriti_native_services.dart';
import '../../../core/auth/user_context.dart';

class PatientWelcomeController {
  PatientWelcomeController._();

  static final PatientWelcomeController instance =
      PatientWelcomeController._();

  bool _started = false;

  Future<void> start() async {
    if (_started) return;
    _started = true;

    try {
      await SmritiNativeServices.music.play();
    } catch (e) {
      debugPrint('Welcome music unavailable: $e');
    }

    final patientId = UserContext.patientIdForCurrentUser;

    try {
      await SmritiNativeServices.voice.speak(
        patientId == null
            ? 'Welcome to SmritiAI.'
            : 'Welcome back. It is good to see you.',
        locale: 'en-IN',
      );
    } catch (e) {
      debugPrint('Welcome voice unavailable: $e');
    }
  }

  Future<void> stop() async {
    await SmritiNativeServices.music.stop();
    await SmritiNativeServices.voice.stop();
    _started = false;
  }
}
