
import 'package:flutter/material.dart';

import '../../../core/auth/user_context.dart';
import '../models/memory_story.dart';
import '../models/story_recall_event.dart';
import '../services/memory_service.dart';

class StoryRecallScreen extends StatefulWidget {
  final String? patientId;
  final String? initialStoryId;

  const StoryRecallScreen({
    super.key,
    this.patientId,
    this.initialStoryId,
  });

  @override
  State<StoryRecallScreen> createState() =>
      _StoryRecallScreenState();
}

class _StoryRecallScreenState
    extends State<StoryRecallScreen> {

  late String patientId;
  MemoryStory? story;

  final recallController =
      TextEditingController();

  bool started = false;
  bool completed = false;

  @override
  void initState() {
    super.initState();

    patientId =
        widget.patientId ??
        UserContext.patientIdForCurrentUser ??
        UserContext.patientIdForCaregiver ??
        'p1';

    final stories =
        MemoryService.instance.getStories(patientId);

    if (widget.initialStoryId != null) {
      for (final item in stories) {
        if (item.id == widget.initialStoryId) {
          story = item;
          break;
        }
      }
    }

    story ??= stories.isEmpty
        ? null
        : stories.first;
  }

  @override
  void dispose() {
    recallController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (story == null) {
      return Scaffold(
        appBar: AppBar(
          title: const Text('Remember Together'),
        ),
        body: const Center(
          child: Padding(
            padding: EdgeInsets.all(30),
            child: Text(
              'There are no memory stories yet.\n\n'
              'A caregiver can add a personal story first.',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 18),
            ),
          ),
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Remember Together',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          if (story!.imageUrl.isNotEmpty)
            ClipRRect(
              borderRadius: BorderRadius.circular(20),
              child: Image.network(
                story!.imageUrl,
                height: 220,
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) =>
                    const SizedBox.shrink(),
              ),
            ),

          if (story!.imageUrl.isNotEmpty)
            const SizedBox(height: 18),

          Text(
            story!.title,
            style: const TextStyle(
              fontSize: 27,
              fontWeight: FontWeight.bold,
            ),
          ),

          const SizedBox(height: 14),

          Card(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Text(
                story!.story,
                style: const TextStyle(
                  fontSize: 19,
                  height: 1.55,
                ),
              ),
            ),
          ),

          const SizedBox(height: 18),

          if (!started)
            _startCard()
          else if (!completed)
            _recallCard()
          else
            _completedCard(),
        ],
      ),
    );
  }

  Widget _startCard() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            const Icon(
              Icons.chat_bubble_outline,
              size: 42,
            ),
            const SizedBox(height: 12),
            const Text(
              'Talk about this memory',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 21,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),
            const Text(
              'Take your time. There are no wrong answers.',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 16),
            ),
            const SizedBox(height: 18),
            SizedBox(
              width: double.infinity,
              height: 54,
              child: FilledButton(
                onPressed: () {
                  setState(() {
                    started = true;
                  });
                },
                child: const Text(
                  'Start Remembering',
                  style: TextStyle(fontSize: 17),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _recallCard() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment:
              CrossAxisAlignment.start,
          children: [
            const Text(
              'What do you remember?',
              style: TextStyle(
                fontSize: 21,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),
            const Text(
              'Tell us anything that comes to mind.',
              style: TextStyle(fontSize: 15),
            ),
            const SizedBox(height: 15),
            TextField(
              controller: recallController,
              minLines: 4,
              maxLines: 7,
              decoration: const InputDecoration(
                hintText:
                    'Type or describe the memory here...',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 15),
            SizedBox(
              width: double.infinity,
              height: 54,
              child: FilledButton.icon(
                onPressed: _saveRecall,
                icon: const Icon(Icons.favorite_outline),
                label: const Text(
                  'Save My Memory',
                  style: TextStyle(fontSize: 17),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _completedCard() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(22),
        child: Column(
          children: [
            const Icon(
              Icons.check_circle_outline,
              size: 52,
            ),
            const SizedBox(height: 12),
            const Text(
              'Thank you for sharing.',
              style: TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),
            const Text(
              'This memory can be revisited with your caregiver.',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 15),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _saveRecall() async {
    final text =
        recallController.text.trim();

    final event = StoryRecallEvent(
      id: DateTime.now()
          .microsecondsSinceEpoch
          .toString(),
      patientId: patientId,
      storyId: story!.id,
      createdAt: DateTime.now(),
      independentRecall: text,
      cuedRecall: '',
      notes: '',
    );

    await MemoryService.instance
        .addStoryRecall(event);

    setState(() {
      completed = true;
    });
  }
}
