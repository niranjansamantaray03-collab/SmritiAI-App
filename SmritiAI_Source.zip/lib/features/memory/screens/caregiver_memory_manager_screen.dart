
import 'package:flutter/material.dart';

import '../../../core/auth/user_context.dart';
import '../models/memory_story.dart';
import '../services/memory_service.dart';
import 'memory_album_screen.dart';
import 'memory_people_screen.dart';

class CaregiverMemoryManagerScreen
    extends StatefulWidget {
  final String? patientId;

  const CaregiverMemoryManagerScreen({
    super.key,
    this.patientId,
  });

  @override
  State<CaregiverMemoryManagerScreen> createState() =>
      _CaregiverMemoryManagerScreenState();
}

class _CaregiverMemoryManagerScreenState
    extends State<CaregiverMemoryManagerScreen> {

  late String patientId;

  @override
  void initState() {
    super.initState();

    patientId =
        widget.patientId ??
        UserContext.patientIdForCaregiver ??
        'p1';
  }

  @override
  Widget build(BuildContext context) {
    final stories =
        MemoryService.instance.getStories(patientId);

    final people =
        MemoryService.instance.getPeople(patientId);

    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Memory Manager',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Row(
                children: [
                  const Icon(
                    Icons.photo_library_outlined,
                    size: 42,
                  ),
                  const SizedBox(width: 15),
                  Expanded(
                    child: Column(
                      crossAxisAlignment:
                          CrossAxisAlignment.start,
                      children: [
                        const Text(
                          'Personal Memory Space',
                          style: TextStyle(
                            fontSize: 21,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 5),
                        Text(
                          '${people.length} people • '
                          '${stories.length} stories',
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),

          const SizedBox(height: 14),

          ListTile(
            leading: const Icon(Icons.people_outline),
            title: const Text(
              'Manage People',
              style: TextStyle(
                fontWeight: FontWeight.bold,
              ),
            ),
            subtitle: const Text(
              'Family, friends and familiar people',
            ),
            trailing: const Icon(Icons.chevron_right),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) =>
                      MemoryPeopleScreen(
                    patientId: patientId,
                  ),
                ),
              ).then((_) => setState(() {}));
            },
          ),

          const Divider(),

          ListTile(
            leading:
                const Icon(Icons.photo_album_outlined),
            title: const Text(
              'Open Patient Memory Album',
              style: TextStyle(
                fontWeight: FontWeight.bold,
              ),
            ),
            subtitle: const Text(
              'View the patient-facing memory experience',
            ),
            trailing: const Icon(Icons.chevron_right),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) =>
                      MemoryAlbumScreen(
                    patientId: patientId,
                  ),
                ),
              );
            },
          ),

          const SizedBox(height: 16),

          const Text(
            'Memory Stories',
            style: TextStyle(
              fontSize: 21,
              fontWeight: FontWeight.bold,
            ),
          ),

          const SizedBox(height: 10),

          ...stories.map(
            (story) => Card(
              child: ListTile(
                leading: const Icon(
                  Icons.auto_stories_outlined,
                ),
                title: Text(
                  story.title,
                  style: const TextStyle(
                    fontWeight: FontWeight.bold,
                  ),
                ),
                subtitle: Text(
                  story.story,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
                trailing: IconButton(
                  icon: const Icon(
                    Icons.delete_outline,
                  ),
                  onPressed: () async {
                    await MemoryService.instance
                        .deleteStory(
                      patientId,
                      story.id,
                    );
                    setState(() {});
                  },
                ),
              ),
            ),
          ),

          const SizedBox(height: 12),

          FilledButton.icon(
            onPressed: _addStory,
            icon: const Icon(Icons.add),
            label: const Text(
              'Create Memory Story',
              style: TextStyle(fontSize: 16),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _addStory() async {
    final titleController =
        TextEditingController();

    final storyController =
        TextEditingController();

    final result =
        await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text(
          'Create Memory Story',
        ),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: titleController,
                decoration: const InputDecoration(
                  labelText: 'Story title',
                  hintText:
                      'Example: Our Trip to Goa',
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: storyController,
                minLines: 4,
                maxLines: 8,
                decoration: const InputDecoration(
                  labelText: 'Story',
                  hintText:
                      'Write a short personal memory...',
                ),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () =>
                Navigator.pop(context, false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () =>
                Navigator.pop(context, true),
            child: const Text('Save'),
          ),
        ],
      ),
    );

    if (result != true) return;

    final title =
        titleController.text.trim();

    final story =
        storyController.text.trim();

    if (title.isEmpty || story.isEmpty) return;

    await MemoryService.instance.addStory(
      MemoryStory(
        id: DateTime.now()
            .microsecondsSinceEpoch
            .toString(),
        patientId: patientId,
        title: title,
        story: story,
        imageUrl: '',
        createdAt: DateTime.now(),
        tags: const [],
      ),
    );

    setState(() {});
  }
}
