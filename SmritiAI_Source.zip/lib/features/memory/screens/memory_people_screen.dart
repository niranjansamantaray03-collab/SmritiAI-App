
import 'package:flutter/material.dart';

import '../../../core/auth/user_context.dart';
import '../models/memory_person.dart';
import '../services/memory_service.dart';

class MemoryPeopleScreen extends StatefulWidget {
  final String? patientId;

  const MemoryPeopleScreen({
    super.key,
    this.patientId,
  });

  @override
  State<MemoryPeopleScreen> createState() =>
      _MemoryPeopleScreenState();
}

class _MemoryPeopleScreenState
    extends State<MemoryPeopleScreen> {

  late String patientId;

  @override
  void initState() {
    super.initState();

    patientId =
        widget.patientId ??
        UserContext.patientIdForCurrentUser ??
        UserContext.patientIdForCaregiver ??
        'p1';
  }

  @override
  Widget build(BuildContext context) {
    final people =
        MemoryService.instance.getPeople(patientId);

    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'People I Know',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _addPerson,
        icon: const Icon(Icons.person_add),
        label: const Text('Add Person'),
      ),
      body: people.isEmpty
          ? _empty()
          : ListView.builder(
              padding: const EdgeInsets.all(18),
              itemCount: people.length,
              itemBuilder: (_, index) {
                final person = people[index];

                return Card(
                  margin:
                      const EdgeInsets.only(bottom: 12),
                  child: ListTile(
                    contentPadding:
                        const EdgeInsets.all(14),
                    leading: const CircleAvatar(
                      radius: 27,
                      child: Icon(
                        Icons.person,
                        size: 30,
                      ),
                    ),
                    title: Text(
                      person.name,
                      style: const TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    subtitle: Text(
                      person.relationship.isEmpty
                          ? 'Familiar person'
                          : person.relationship,
                    ),
                    trailing: IconButton(
                      icon: const Icon(
                        Icons.delete_outline,
                      ),
                      onPressed: () async {
                        await MemoryService.instance
                            .deletePerson(
                          patientId,
                          person.id,
                        );
                        setState(() {});
                      },
                    ),
                  ),
                );
              },
            ),
    );
  }

  Widget _empty() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(30),
        child: Column(
          mainAxisAlignment:
              MainAxisAlignment.center,
          children: [
            const Icon(
              Icons.people_outline,
              size: 70,
            ),
            const SizedBox(height: 18),
            const Text(
              'No familiar people yet',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 23,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),
            const Text(
              'Add family members or important people '
              'to make memories easier to recognize.',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 16),
            ),
            const SizedBox(height: 22),
            FilledButton.icon(
              onPressed: _addPerson,
              icon: const Icon(Icons.person_add),
              label: const Text('Add Person'),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _addPerson() async {
    final nameController = TextEditingController();
    final relationshipController =
        TextEditingController();

    final result =
        await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Add a Person'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: nameController,
              decoration: const InputDecoration(
                labelText: 'Name',
                hintText: 'Example: Meera',
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: relationshipController,
              decoration: const InputDecoration(
                labelText: 'Relationship',
                hintText:
                    'Example: Daughter, Brother, Friend',
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () =>
                Navigator.pop(context, false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () =>
                Navigator.pop(context, true),
            child: const Text('Save'),
          ),
        ],
      ),
    );

    if (result != true) return;

    final name =
        nameController.text.trim();

    if (name.isEmpty) return;

    await MemoryService.instance.addPerson(
      MemoryPerson(
        id: DateTime.now()
            .microsecondsSinceEpoch
            .toString(),
        patientId: patientId,
        name: name,
        relationship:
            relationshipController.text.trim(),
        imageUrl: '',
      ),
    );

    setState(() {});
  }
}
