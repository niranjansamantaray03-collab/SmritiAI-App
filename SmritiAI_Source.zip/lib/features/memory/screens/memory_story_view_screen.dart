import 'package:flutter/material.dart';

import '../services/memory_service.dart';

class MemoryStoryViewScreen extends StatelessWidget {
  final String patientId;
  final String storyId;

  const MemoryStoryViewScreen({
    super.key,
    required this.patientId,
    required this.storyId,
  });

  @override
  Widget build(BuildContext context) {
    final story = MemoryService.instance.getStory(
      patientId,
      storyId,
    );

    if (story == null) {
      return Scaffold(
        appBar: AppBar(
          title: const Text('Memory Story'),
        ),
        body: const Center(
          child: Text(
            'Memory story not found.',
            style: TextStyle(fontSize: 20),
          ),
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Memory Story'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Text(
            story.title,
            style: const TextStyle(
              fontSize: 30,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 18),

          if (story.imageUrl != null &&
              story.imageUrl!.isNotEmpty)
            ClipRRect(
              borderRadius: BorderRadius.circular(20),
              child: Image.network(
                story.imageUrl!,
                height: 240,
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) {
                  return const SizedBox(
                    height: 180,
                    child: Center(
                      child: Icon(
                        Icons.image_not_supported,
                        size: 55,
                      ),
                    ),
                  );
                },
              ),
            ),

          if (story.imageUrl != null &&
              story.imageUrl!.isNotEmpty)
            const SizedBox(height: 20),

          Card(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Text(
                story.story,
                style: const TextStyle(
                  fontSize: 21,
                  height: 1.5,
                ),
              ),
            ),
          ),

          if (story.tags.isNotEmpty) ...[
            const SizedBox(height: 18),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: story.tags.map(
                (tag) => Chip(
                  label: Text(
                    tag,
                    style: const TextStyle(fontSize: 15),
                  ),
                ),
              ).toList(),
            ),
          ],
        ],
      ),
    );
  }
}
