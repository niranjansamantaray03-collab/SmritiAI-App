
import '../models/memory_media.dart';
import 'media_storage_service.dart';
import '../../../data/persistence/persistence_manager.dart';
import '../../../data/sync/sync_manager.dart';
import '../../../core/auth/user_context.dart';

class MemoryMediaService {
  MemoryMediaService._();

  static final MemoryMediaService instance =
      MemoryMediaService._();

  MediaStorageService? _storage;

  final Map<String, MemoryMedia> _media = {};

  bool _loaded = false;

  void configure(
    MediaStorageService storage,
  ) {
    _storage = storage;
  }

  Future<void> initialize() async {
    if (_loaded) return;

    final records =
        await PersistenceManager.instance
            .getAll('memory_media');

    for (final record in records) {
      try {
        final item =
            MemoryMedia.fromMap(record);

        _media[item.id] = item;
      } catch (_) {}
    }

    _loaded = true;
  }

  Future<List<MemoryMedia>> getForPatient(
    String patientId,
  ) async {
    await initialize();

    return _media.values
        .where(
          (item) =>
              item.patientId ==
              patientId,
        )
        .toList()
      ..sort(
        (a, b) => b.createdAt
            .compareTo(a.createdAt),
      );
  }

  Future<MemoryMedia?> addPhotoFromGallery({
    required String patientId,
    String? storyId,
  }) async {
    await initialize();

    final storage = _storage;

    if (storage == null) {
      return null;
    }

    final media =
        await storage.pickPhoto(
      patientId: patientId,
      storyId: storyId,
    );

    if (media == null) return null;

    await _save(media);

    return media;
  }

  Future<MemoryMedia?> capturePhoto({
    required String patientId,
    String? storyId,
  }) async {
    await initialize();

    final storage = _storage;

    if (storage == null) {
      return null;
    }

    final media =
        await storage.capturePhoto(
      patientId: patientId,
      storyId: storyId,
    );

    if (media == null) return null;

    await _save(media);

    return media;
  }

  Future<MemoryMedia?> addAudio({
    required String patientId,
    String? storyId,
    required String title,
  }) async {
    await initialize();

    final storage = _storage;

    if (storage == null) {
      return null;
    }

    final media =
        await storage.recordAudio(
      patientId: patientId,
      storyId: storyId,
      title: title,
    );

    if (media == null) return null;

    await _save(media);

    return media;
  }

  Future<void> delete(
    MemoryMedia media,
  ) async {
    _media.remove(media.id);

    await PersistenceManager.instance
        .delete(
      'memory_media',
      media.id,
    );

    final storage = _storage;

    if (storage != null) {
      await storage.delete(media);
    }

    SyncManager.instance.queueRecord(
      collection: 'memory_media',
      patientId: media.patientId,
      operation: 'delete',
      data: {
        'id': media.id,
        'patient_id': media.patientId,
        'deleted': true,
      },
    );
  }

  Future<void> _save(
    MemoryMedia media,
  ) async {
    _media[media.id] = media;

    await PersistenceManager.instance
        .save(
      'memory_media',
      media.id,
      media.toMap(),
    );

    SyncManager.instance.queueRecord(
      collection: 'memory_media',
      patientId: media.patientId,
      operation: 'upsert',
      data: media.toMap(),
    );
  }
}
