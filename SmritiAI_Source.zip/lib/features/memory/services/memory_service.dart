
import '../models/memory_person.dart';
import '../models/memory_story.dart';
import '../models/story_recall_event.dart';

class MemoryService {
  MemoryService._();

  static final MemoryService instance =
      MemoryService._();

  final Map<String, List<MemoryPerson>> _people = {};
  final Map<String, List<MemoryStory>> _stories = {};
  final Map<String, List<StoryRecallEvent>> _recalls = {};

  List<MemoryPerson> getPeople(String patientId) {
    return List.unmodifiable(
      _people[patientId] ?? const [],
    );
  }

  List<MemoryStory> getStories(String patientId) {
    return List.unmodifiable(
      _stories[patientId] ?? const [],
    );
  }

  List<StoryRecallEvent> getRecalls(
    String patientId,
  ) {
    return List.unmodifiable(
      _recalls[patientId] ?? const [],
    );
  }

  Future<void> addPerson(
    MemoryPerson person,
  ) async {
    final list =
        _people.putIfAbsent(
      person.patientId,
      () => [],
    );

    list.removeWhere(
      (item) => item.id == person.id,
    );

    list.add(person);
  }

  Future<void> deletePerson(
    String patientId,
    String personId,
  ) async {
    _people[patientId]?.removeWhere(
      (item) => item.id == personId,
    );
  }

  Future<void> addStory(
    MemoryStory story,
  ) async {
    final list =
        _stories.putIfAbsent(
      story.patientId,
      () => [],
    );

    list.removeWhere(
      (item) => item.id == story.id,
    );

    list.add(story);
  }

  Future<void> deleteStory(
    String patientId,
    String storyId,
  ) async {
    _stories[patientId]?.removeWhere(
      (item) => item.id == storyId,
    );
  }

  Future<void> addStoryRecall(
    StoryRecallEvent event,
  ) async {
    final list =
        _recalls.putIfAbsent(
      event.patientId,
      () => [],
    );

    list.add(event);
  }

  Future<void> seedDemoMemory(
    String patientId,
  ) async {
    if (getPeople(patientId).isEmpty) {
      await addPerson(
        MemoryPerson(
          id: 'person_meera_$patientId',
          patientId: patientId,
          name: 'Meera',
          relationship: 'Daughter',
          imageUrl: '',
        ),
      );

      await addPerson(
        MemoryPerson(
          id: 'person_family_$patientId',
          patientId: patientId,
          name: 'Family',
          relationship: 'Family',
          imageUrl: '',
        ),
      );
    }

    if (getStories(patientId).isEmpty) {
      await addStory(
        MemoryStory(
          id: 'story_demo_$patientId',
          patientId: patientId,
          title: 'A Special Family Day',
          story:
              'This is a personal memory story. '
              'A caregiver can replace this demo story '
              'with a meaningful family memory.',
          imageUrl: '',
          createdAt: DateTime.now(),
          tags: const ['family', 'memory'],
        ),
      );
    }
  }

  void clearPatient(String patientId) {
    _people.remove(patientId);
    _stories.remove(patientId);
    _recalls.remove(patientId);
  }
}
