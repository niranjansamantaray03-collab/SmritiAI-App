
import '../../../data/persistence/feature_write_service.dart';
import '../models/memory_person.dart';
import '../models/memory_story.dart';
import '../models/story_recall_event.dart';

class MemoryPersistenceAdapter {
  MemoryPersistenceAdapter._();

  static final MemoryPersistenceAdapter instance =
      MemoryPersistenceAdapter._();

  Future<void> saveStory(MemoryStory story) {
    return FeatureWriteService.instance.saveStory(story);
  }

  Future<void> savePerson(MemoryPerson person) {
    return FeatureWriteService.instance.savePerson(person);
  }

  Future<void> saveRecall(StoryRecallEvent event) {
    return FeatureWriteService.instance.saveStoryRecall(event);
  }
}
