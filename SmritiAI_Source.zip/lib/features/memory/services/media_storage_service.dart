
import '../models/memory_media.dart';

abstract class MediaStorageService {
  Future<void> initialize();

  Future<MemoryMedia?> pickPhoto({
    required String patientId,
    String? storyId,
  });

  Future<MemoryMedia?> capturePhoto({
    required String patientId,
    String? storyId,
  });

  Future<MemoryMedia?> recordAudio({
    required String patientId,
    String? storyId,
    required String title,
  });

  Future<String?> upload(
    MemoryMedia media,
  );

  Future<void> delete(
    MemoryMedia media,
  );
}

/*
Production Android implementation:

Photo:
  image_picker / camera
      ↓
  local temporary file
      ↓
  Supabase Storage: memory-photos
      ↓
  memory_photos table

Audio:
  Android microphone
      ↓
  local audio file
      ↓
  Supabase Storage: memory-audio
      ↓
  memory_stories / media metadata

The feature layer only depends on this contract.
*/
