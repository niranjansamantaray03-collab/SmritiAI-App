class MemoryPhoto {
  final String id;
  final String patientId;
  final String title;
  final String imageUrl;
  final String? description;
  final DateTime createdAt;
  final String? capturedDate;
  final List<String> people;
  final String? location;

  const MemoryPhoto({
    required this.id,
    required this.patientId,
    required this.title,
    required this.imageUrl,
    this.description,
    required this.createdAt,
    this.capturedDate,
    this.people = const [],
    this.location,
  });

  MemoryPhoto copyWith({
    String? title,
    String? imageUrl,
    String? description,
    String? capturedDate,
    List<String>? people,
    String? location,
  }) {
    return MemoryPhoto(
      id: id,
      patientId: patientId,
      title: title ?? this.title,
      imageUrl: imageUrl ?? this.imageUrl,
      description: description ?? this.description,
      createdAt: createdAt,
      capturedDate: capturedDate ?? this.capturedDate,
      people: people ?? this.people,
      location: location ?? this.location,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'patientId': patientId,
      'title': title,
      'imageUrl': imageUrl,
      'description': description,
      'createdAt': createdAt.toIso8601String(),
      'capturedDate': capturedDate,
      'people': people,
      'location': location,
    };
  }

  factory MemoryPhoto.fromMap(Map<String, dynamic> map) {
    return MemoryPhoto(
      id: map['id'] as String,
      patientId: map['patientId'] as String,
      title: map['title'] as String? ?? '',
      imageUrl: map['imageUrl'] as String? ?? '',
      description: map['description'] as String?,
      createdAt: DateTime.tryParse(
            map['createdAt'] as String? ?? '',
          ) ??
          DateTime.now(),
      capturedDate: map['capturedDate'] as String?,
      people: List<String>.from(
        map['people'] as List? ?? const [],
      ),
      location: map['location'] as String?,
    );
  }
}
