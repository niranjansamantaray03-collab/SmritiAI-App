
class MemoryPerson {
  final String id;
  final String patientId;
  final String name;
  final String relationship;
  final String? photoUrl;
  final String? description;

  const MemoryPerson({
    required this.id,
    required this.patientId,
    required this.name,
    required this.relationship,
    this.photoUrl,
    this.description,
  });

  Map<String, dynamic> toMap() => {
    'id': id,
    'patient_id': patientId,
    'name': name,
    'relationship': relationship,
    'photo_url': photoUrl,
    'description': description,
  };

  factory MemoryPerson.fromMap(Map<String, dynamic> map) {
    return MemoryPerson(
      id: map['id']?.toString() ?? '',
      patientId: map['patient_id']?.toString() ?? '',
      name: map['name']?.toString() ?? '',
      relationship: map['relationship']?.toString() ?? '',
      photoUrl: map['photo_url']?.toString(),
      description: map['description']?.toString(),
    );
  }
}
