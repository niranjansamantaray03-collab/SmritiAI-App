
import '../../../data/persistence/feature_write_service.dart';
import '../models/caregiver_task.dart';

class TaskPersistenceAdapter {
  TaskPersistenceAdapter._();

  static final TaskPersistenceAdapter instance =
      TaskPersistenceAdapter._();

  Future<void> save(CaregiverTask task) {
    return FeatureWriteService.instance.saveTask(task);
  }
}
