
import 'package:flutter/material.dart';
import '../../../core/auth/user_context.dart';
import '../services/task_service.dart';
import '../models/caregiver_task.dart';

class PatientTasksScreen extends StatefulWidget {
  const PatientTasksScreen({super.key});

  @override
  State<PatientTasksScreen> createState() => _PatientTasksScreenState();
}

class _PatientTasksScreenState extends State<PatientTasksScreen> {
  final service = TaskService.instance;

  String? get patientId => UserContext.patientIdForCurrentUser;

  @override
  void initState() {
    super.initState();
    final id = patientId;
    if (id != null) {
      service.seedForPatientIfNeeded(id, 'c1');
    }
  }

  @override
  Widget build(BuildContext context) {
    final id = patientId;

    if (id == null) {
      return Scaffold(
        appBar: AppBar(title: const Text('My Tasks')),
        body: const Center(
          child: Text('Patient account is not connected yet.'),
        ),
      );
    }

    final tasks = service.getTasksForPatient(id);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Today’s Tasks'),
      ),
      body: tasks.isEmpty
          ? const Center(
              child: Text(
                'No tasks assigned yet.',
                style: TextStyle(fontSize: 20),
              ),
            )
          : ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: tasks.length,
              itemBuilder: (_, index) {
                final task = tasks[index];
                return _TaskTile(
                  task: task,
                  onComplete: () {
                    service.complete(id, task.id);
                    setState(() {});
                  },
                  onReopen: () {
                    service.reopen(id, task.id);
                    setState(() {});
                  },
                );
              },
            ),
    );
  }
}

class _TaskTile extends StatelessWidget {
  final CaregiverTask task;
  final VoidCallback onComplete;
  final VoidCallback onReopen;

  const _TaskTile({
    required this.task,
    required this.onComplete,
    required this.onReopen,
  });

  @override
  Widget build(BuildContext context) {
    final status = task.completed
        ? 'Completed'
        : task.isOverdue
            ? 'Overdue'
            : 'Pending';

    return Card(
      margin: const EdgeInsets.only(bottom: 14),
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Row(
          children: [
            Icon(
              task.completed
                  ? Icons.check_circle
                  : task.isOverdue
                      ? Icons.warning_amber_rounded
                      : Icons.radio_button_unchecked,
              size: 36,
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    task.title,
                    style: const TextStyle(
                      fontSize: 21,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  if (task.description.isNotEmpty) ...[
                    const SizedBox(height: 5),
                    Text(
                      task.description,
                      style: const TextStyle(fontSize: 17),
                    ),
                  ],
                  const SizedBox(height: 7),
                  Text(
                    '$status • ${_format(task.dueAt)}',
                    style: const TextStyle(fontSize: 15),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 8),
            task.completed
                ? IconButton(
                    tooltip: 'Reopen',
                    onPressed: onReopen,
                    icon: const Icon(Icons.undo),
                  )
                : FilledButton(
                    onPressed: onComplete,
                    child: const Text('Done'),
                  ),
          ],
        ),
      ),
    );
  }

  String _format(DateTime d) {
    final hour = d.hour % 12 == 0 ? 12 : d.hour % 12;
    final minute = d.minute.toString().padLeft(2, '0');
    final suffix = d.hour >= 12 ? 'PM' : 'AM';
    return '$hour:$minute $suffix';
  }
}
