
import 'package:flutter/material.dart';
import '../../../core/auth/user_context.dart';
import '../services/task_service.dart';

class CaregiverTasksScreen extends StatefulWidget {
  final String? patientId;

  const CaregiverTasksScreen({
    super.key,
    this.patientId,
  });

  @override
  State<CaregiverTasksScreen> createState() => _CaregiverTasksScreenState();
}

class _CaregiverTasksScreenState extends State<CaregiverTasksScreen> {
  String? get patientId =>
      widget.patientId ?? UserContext.patientIdForCaregiver;

  @override
  Widget build(BuildContext context) {
    final pid = patientId;

    if (pid == null) {
      return Scaffold(
        appBar: AppBar(title: const Text('Tasks & Progress')),
        body: const Center(
          child: Text('No connected patient selected.'),
        ),
      );
    }

    final service = TaskService.instance;
    final tasks = service.getTasksForPatient(pid);
    final completed = service.completedCount(pid);
    final total = service.totalCount(pid);
    final overdue = service.overdueCount(pid);
    final rate = service.completionRate(pid);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Tasks & Progress'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Task completion',
                    style: TextStyle(
                      fontSize: 21,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 14),
                  LinearProgressIndicator(value: rate),
                  const SizedBox(height: 12),
                  Text(
                    '$completed of $total completed',
                    style: const TextStyle(fontSize: 18),
                  ),
                  if (overdue > 0) ...[
                    const SizedBox(height: 8),
                    Text(
                      '$overdue overdue',
                      style: const TextStyle(fontSize: 17),
                    ),
                  ],
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          ...tasks.map(
            (task) => Card(
              child: ListTile(
                leading: Icon(
                  task.completed
                      ? Icons.check_circle
                      : task.isOverdue
                          ? Icons.warning_amber
                          : Icons.schedule,
                ),
                title: Text(
                  task.title,
                  style: const TextStyle(fontSize: 18),
                ),
                subtitle: Text(
                  task.completed
                      ? 'Completed ${_format(task.completedAt)}'
                      : task.isOverdue
                          ? 'Overdue • ${_format(task.dueAt)}'
                          : 'Due ${_format(task.dueAt)}',
                ),
                trailing: task.completed
                    ? IconButton(
                        tooltip: 'Reopen',
                        icon: const Icon(Icons.undo),
                        onPressed: () {
                          service.reopen(pid, task.id);
                          setState(() {});
                        },
                      )
                    : IconButton(
                        tooltip: 'Mark complete',
                        icon: const Icon(Icons.check),
                        onPressed: () {
                          service.complete(pid, task.id);
                          setState(() {});
                        },
                      ),
              ),
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () async {
          final result = await Navigator.pushNamed(
            context,
            '/caregiver/assign-task',
            arguments: pid,
          );
          if (result == true) setState(() {});
        },
        icon: const Icon(Icons.add_task),
        label: const Text('Assign'),
      ),
    );
  }

  String _format(DateTime? d) {
    if (d == null) return '';
    final hour = d.hour % 12 == 0 ? 12 : d.hour % 12;
    final minute = d.minute.toString().padLeft(2, '0');
    final suffix = d.hour >= 12 ? 'PM' : 'AM';
    return '$hour:$minute $suffix';
  }
}
