
import 'package:flutter/material.dart';

import '../services/rudas_service.dart';

class RudasCheckpointStatusScreen
    extends StatefulWidget {
  const RudasCheckpointStatusScreen({
    super.key,
    required this.patientId,
  });

  final String patientId;

  @override
  State<RudasCheckpointStatusScreen>
      createState() =>
          _RudasCheckpointStatusScreenState();
}

class _RudasCheckpointStatusScreenState
    extends State<
        RudasCheckpointStatusScreen> {
  int sessions = 0;
  bool due = false;
  int remaining = 7;
  bool loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final service =
        RudasService.instance;

    sessions =
        await service
            .completedGameSessions(
      widget.patientId,
    );

    due =
        await service
            .isReassessmentDue(
      widget.patientId,
    );

    remaining =
        await service
            .sessionsUntilNextAssessment(
      widget.patientId,
    );

    if (mounted) {
      setState(
        () => loading = false,
      );
    }
  }

  @override
  Widget build(
    BuildContext context,
  ) {
    if (loading) {
      return const Scaffold(
        body: Center(
          child:
              CircularProgressIndicator(),
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'RUDAS Checkpoint',
        ),
      ),
      body: Padding(
        padding:
            const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment:
              CrossAxisAlignment.stretch,
          children: [
            Card(
              child: Padding(
                padding:
                    const EdgeInsets.all(24),
                child: Column(
                  children: [
                    const Icon(
                      Icons.assessment_outlined,
                      size: 48,
                    ),
                    const SizedBox(
                      height: 12,
                    ),
                    Text(
                      '$sessions',
                      style: Theme.of(
                        context,
                      )
                          .textTheme
                          .displaySmall,
                    ),
                    const Text(
                      'completed game sessions',
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(
              height: 16,
            ),
            Card(
              child: Padding(
                padding:
                    const EdgeInsets.all(20),
                child: Text(
                  due
                      ? 'RUDAS reassessment is due.'
                      : '$remaining game sessions until the next RUDAS checkpoint.',
                  textAlign:
                      TextAlign.center,
                  style: Theme.of(
                    context,
                  )
                      .textTheme
                      .titleMedium,
                ),
              ),
            ),
            const SizedBox(
              height: 16,
            ),
            const Text(
              'Important: cognitive games do not calculate the RUDAS score. The RUDAS assessment is administered separately.',
              textAlign:
                  TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}
