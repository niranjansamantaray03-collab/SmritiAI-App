
import 'package:flutter/material.dart';

import '../../../core/auth/user_context.dart';
import '../services/rudas_first_assessment_service.dart';
import 'rudas_assessment_screen.dart';
import 'rudas_hand_jumble_screen.dart';

class RudasFirstAssessmentGate
    extends StatefulWidget {
  final String? patientId;

  const RudasFirstAssessmentGate({
    super.key,
    this.patientId,
  });

  @override
  State<RudasFirstAssessmentGate> createState() =>
      _RudasFirstAssessmentGateState();
}

class _RudasFirstAssessmentGateState
    extends State<RudasFirstAssessmentGate> {

  bool loading = true;
  bool firstAssessment = false;

  String get resolvedPatientId =>
      widget.patientId ??
      UserContext.patientIdForCurrentUser ??
      UserContext.patientIdForCaregiver ??
      'current_patient';

  @override
  void initState() {
    super.initState();
    _check();
  }

  Future<void> _check() async {
    final value =
        await RudasFirstAssessmentService
            .instance
            .isFirstAssessment(
              resolvedPatientId,
            );

    if (!mounted) return;

    setState(() {
      firstAssessment = value;
      loading = false;
    });
  }

  void _continue() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) =>
            RudasAssessmentScreen(
          patientId: resolvedPatientId,
        ),
      ),
    );
  }

  Future<void> _startHandJumble() async {
    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) =>
            RudasHandJumbleScreen(
          patientId: resolvedPatientId,
          firstAssessment: true,
        ),
      ),
    );

    if (!mounted) return;

    await RudasFirstAssessmentService
        .instance
        .markHandJumbleCompleted(
          resolvedPatientId,
        );

    if (!mounted) return;

    _continue();
  }

  @override
  Widget build(BuildContext context) {
    if (loading) {
      return const Scaffold(
        body: Center(
          child: CircularProgressIndicator(),
        ),
      );
    }

    if (!firstAssessment) {
      return RudasAssessmentScreen(
        patientId: resolvedPatientId,
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'First RUDAS Assessment',
        ),
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            const Icon(
              Icons.videocam_outlined,
              size: 72,
            ),
            const SizedBox(height: 20),

            const Text(
              'First-time hand and body assessment',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 25,
                fontWeight: FontWeight.bold,
              ),
            ),

            const SizedBox(height: 14),

            const Text(
              'Before the first RUDAS scoring session, '
              'the assessor can observe a short series of '
              'hand and body movements using the camera.',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 18),
            ),

            const SizedBox(height: 16),

            Card(
              child: Padding(
                padding: const EdgeInsets.all(18),
                child: Column(
                  children: const [
                    Text(
                      'The camera does not diagnose dementia '
                      'and does not automatically assign a '
                      'RUDAS score.',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 17,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    SizedBox(height: 10),
                    Text(
                      'The assessor records the observations '
                      'and then completes the standard RUDAS '
                      'assessment.',
                      textAlign: TextAlign.center,
                      style: TextStyle(fontSize: 16),
                    ),
                  ],
                ),
              ),
            ),

            const SizedBox(height: 24),

            SizedBox(
              width: double.infinity,
              child: FilledButton.icon(
                onPressed: _startHandJumble,
                icon: const Icon(
                  Icons.camera_alt,
                ),
                label: const Padding(
                  padding: EdgeInsets.all(14),
                  child: Text(
                    'Start hand / body assessment',
                    style: TextStyle(
                      fontSize: 18,
                    ),
                  ),
                ),
              ),
            ),

            const SizedBox(height: 12),

            SizedBox(
              width: double.infinity,
              child: OutlinedButton(
                onPressed: _continue,
                child: const Padding(
                  padding: EdgeInsets.all(12),
                  child: Text(
                    'Skip to RUDAS scoring',
                    style: TextStyle(
                      fontSize: 17,
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
