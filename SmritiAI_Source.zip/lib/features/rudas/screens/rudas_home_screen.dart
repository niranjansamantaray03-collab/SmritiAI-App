import 'package:flutter/material.dart';

import '../services/rudas_service.dart';
import 'rudas_assessment_screen.dart';
import 'rudas_history_screen.dart';
import 'rudas_first_assessment_gate.dart';

class RudasHomeScreen extends StatefulWidget {
  final String patientId;

  const RudasHomeScreen({
    super.key,
    required this.patientId,
  });

  @override
  State<RudasHomeScreen> createState() => _RudasHomeScreenState();
}

class _RudasHomeScreenState extends State<RudasHomeScreen> {
  final RudasService _service = RudasService.instance;

  @override
  void initState() {
    super.initState();

    // Safety net for patients already created before the registration
    // hook is connected. This method is idempotent.
    _service.ensureBaseline(patientId: widget.patientId);
  }

  @override
  Widget build(BuildContext context) {
    final baseline = _service.getBaseline(widget.patientId);
    final sessions = _service.completedGameSessions(widget.patientId);
    final due = _service.isReassessmentDue(widget.patientId);
    final remaining = _service.sessionsUntilNextAssessment(widget.patientId);

    return Scaffold(
      body: Column(
        children: [
            padding: const EdgeInsets.all(12),
            child: SizedBox(
              width: double.infinity,
              child: OutlinedButton.icon(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) =>
                          const RudasFirstAssessmentGate(),
                    ),
                  );
                },
                icon: const Icon(
                  Icons.camera_alt_outlined,
                ),
                label: const Text(
                  'Start first RUDAS assessment',
                  style: TextStyle(fontSize: 17),
                ),
              ),
            ),
          ),
          Expanded(
            child: 
      appBar: AppBar(
        title: const Text('RUDAS & Progress'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    '🧠 RUDAS',
                    style: TextStyle(
                      fontSize: 28,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 10),
                  const Text(
                    'RUDAS assessments are recorded separately from '
                    'cognitive-game performance.',
                    style: TextStyle(fontSize: 18),
                  ),
                  const SizedBox(height: 18),
                  if (baseline == null ||
                      baseline.notes == 'BASELINE') ...[
                    const Text(
                      'Baseline assessment pending',
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ] else ...[
                    Text(
                      'Baseline recorded: ${baseline.total}/30',
                      style: const TextStyle(
                        fontSize: 22,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ],
              ),
            ),
          ),

          const SizedBox(height: 16),

          Card(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    '🎮 Cognitive sessions',
                    style: TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    '$sessions completed game sessions',
                    style: const TextStyle(fontSize: 20),
                  ),
                  const SizedBox(height: 12),
                  if (due)
                    const Text(
                      'RUDAS reassessment is due.',
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    )
                  else
                    Text(
                      '$remaining game sessions until the next checkpoint',
                      style: const TextStyle(fontSize: 18),
                    ),
                ],
              ),
            ),
          ),

          const SizedBox(height: 20),

          SizedBox(
            height: 68,
            child: ElevatedButton.icon(
              icon: const Icon(Icons.psychology_alt, size: 30),
              label: Text(
                due
                    ? 'Complete RUDAS Reassessment'
                    : baseline?.notes == 'BASELINE'
                        ? 'Complete Baseline RUDAS'
                        : 'Record RUDAS Assessment',
                style: const TextStyle(fontSize: 20),
              ),
              onPressed: () async {
                await Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => RudasAssessmentScreen(
                      patientId: widget.patientId,
                    ),
                  ),
                );
                setState(() {});
              },
            ),
          ),

          const SizedBox(height: 14),

          SizedBox(
            height: 64,
            child: OutlinedButton.icon(
              icon: const Icon(Icons.history, size: 28),
              label: const Text(
                'Assessment History',
                style: TextStyle(fontSize: 19),
              ),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => RudasHistoryScreen(
                      patientId: widget.patientId,
                    ),
                  ),
                );
              },
            ),
          ),

          const SizedBox(height: 20),

          const Card(
            child: Padding(
              padding: EdgeInsets.all(18),
              child: Text(
                'Important: Game performance does not automatically '
                'produce a RUDAS score. RUDAS is recorded as a separate '
                'assessment by the authorized assessor.',
                style: TextStyle(fontSize: 17),
              ),
        ],
      ),
    );
  }
}
