class RudasAssessment {
  final String id;
  final String patientId;
  final DateTime date;
  final int memory;
  final int orientation;
  final int praxis;
  final int visuoconstruction;
  final int judgment;
  final int language;
  final int total;
  final String assessorId;
  final String? notes;

  const RudasAssessment({
    required this.id,
    required this.patientId,
    required this.date,
    required this.memory,
    required this.orientation,
    required this.praxis,
    required this.visuoconstruction,
    required this.judgment,
    required this.language,
    required this.total,
    required this.assessorId,
    this.notes,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'patientId': patientId,
      'date': date.toIso8601String(),
      'memory': memory,
      'orientation': orientation,
      'praxis': praxis,
      'visuoconstruction': visuoconstruction,
      'judgment': judgment,
      'language': language,
      'total': total,
      'assessorId': assessorId,
      'notes': notes,
    };
  }

  factory RudasAssessment.fromMap(Map<String, dynamic> map) {
    return RudasAssessment(
      id: map['id'] as String,
      patientId: map['patientId'] as String,
      date: DateTime.parse(map['date'] as String),
      memory: map['memory'] as int,
      orientation: map['orientation'] as int,
      praxis: map['praxis'] as int,
      visuoconstruction: map['visuoconstruction'] as int,
      judgment: map['judgment'] as int,
      language: map['language'] as int,
      total: map['total'] as int,
      assessorId: map['assessorId'] as String,
      notes: map['notes'] as String?,
    );
  }
}
