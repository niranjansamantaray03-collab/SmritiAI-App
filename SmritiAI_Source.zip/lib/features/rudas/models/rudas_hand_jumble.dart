
class RudasHandJumble {
  final String id;
  final String patientId;
  final DateTime performedAt;

  final bool cameraUsed;

  final bool leftHandShown;
  final bool rightHandShown;
  final bool leftToRightShoulder;
  final bool rightToLeftShoulder;

  final bool fistPalmAlternation;
  final bool reverseSequence;

  final int praxisScore;
  final int orientationScore;

  final String assessorNotes;

  const RudasHandJumble({
    required this.id,
    required this.patientId,
    required this.performedAt,
    required this.cameraUsed,
    required this.leftHandShown,
    required this.rightHandShown,
    required this.leftToRightShoulder,
    required this.rightToLeftShoulder,
    required this.fistPalmAlternation,
    required this.reverseSequence,
    required this.praxisScore,
    required this.orientationScore,
    required this.assessorNotes,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'patient_id': patientId,
      'performed_at': performedAt.toIso8601String(),
      'camera_used': cameraUsed,
      'left_hand_shown': leftHandShown,
      'right_hand_shown': rightHandShown,
      'left_to_right_shoulder': leftToRightShoulder,
      'right_to_left_shoulder': rightToLeftShoulder,
      'fist_palm_alternation': fistPalmAlternation,
      'reverse_sequence': reverseSequence,
      'praxis_score': praxisScore,
      'orientation_score': orientationScore,
      'assessor_notes': assessorNotes,
    };
  }
}
