
class RudasHandJumbleObservation {
  final String id;
  final String patientId;
  final String assessorId;
  final DateTime completedAt;
  final List<String> completedSteps;
  final List<String> missedSteps;
  final String assessorNotes;
  final bool referencePhotoCaptured;

  const RudasHandJumbleObservation({
    required this.id,
    required this.patientId,
    required this.assessorId,
    required this.completedAt,
    this.completedSteps = const [],
    this.missedSteps = const [],
    this.assessorNotes = '',
    this.referencePhotoCaptured = false,
  });

  Map<String, dynamic> toMap() => {
        'id': id,
        'patient_id': patientId,
        'assessor_id': assessorId,
        'completed_at': completedAt.toIso8601String(),
        'completed_steps': completedSteps,
        'missed_steps': missedSteps,
        'assessor_notes': assessorNotes,
        'reference_photo_captured': referencePhotoCaptured,
      };

  factory RudasHandJumbleObservation.fromMap(Map<String, dynamic> map) {
    return RudasHandJumbleObservation(
      id: '${map['id'] ?? ''}',
      patientId: '${map['patient_id'] ?? ''}',
      assessorId: '${map['assessor_id'] ?? ''}',
      completedAt: DateTime.tryParse('${map['completed_at'] ?? ''}') ??
          DateTime.fromMillisecondsSinceEpoch(0),
      completedSteps: List<String>.from(map['completed_steps'] ?? const []),
      missedSteps: List<String>.from(map['missed_steps'] ?? const []),
      assessorNotes: '${map['assessor_notes'] ?? ''}',
      referencePhotoCaptured:
          map['reference_photo_captured'] == true,
    );
  }
}
