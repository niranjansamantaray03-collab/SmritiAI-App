
import 'rudas_service.dart';

class RudasRegistrationService {
  RudasRegistrationService._();

  static final RudasRegistrationService instance =
      RudasRegistrationService._();

  bool _registrationCompleted = false;

  Future<void> initializePatientRegistration(
    String patientId,
  ) async {
    if (_registrationCompleted) {
      return;
    }

    // Idempotent: ensureBaseline must never create a second
    // baseline for the same patient.
    RudasService.instance.ensureBaseline(patientId);

    _registrationCompleted = true;
  }

  void resetForTesting() {
    _registrationCompleted = false;
  }
}
