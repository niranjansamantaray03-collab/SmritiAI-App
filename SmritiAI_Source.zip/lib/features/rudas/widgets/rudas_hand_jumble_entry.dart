
import 'package:flutter/material.dart';

import '../screens/rudas_hand_jumble_screen.dart';

class RudasHandJumbleEntry extends StatelessWidget {
  final String patientId;

  const RudasHandJumbleEntry({
    super.key,
    required this.patientId,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Row(
              children: [
                Icon(Icons.pan_tool_outlined, size: 30),
                SizedBox(width: 10),
                Expanded(
                  child: Text(
                    'Hand & Body Orientation',
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            const Text(
              'First-time guided camera assessment for '
              'left/right hand and shoulder movements.',
              style: TextStyle(fontSize: 16),
            ),
            const SizedBox(height: 14),
            SizedBox(
              width: double.infinity,
              child: FilledButton.icon(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => RudasHandJumbleScreen(
                        patientId: patientId,
                      ),
                    ),
                  );
                },
                icon: const Icon(Icons.camera_alt),
                label: const Padding(
                  padding: EdgeInsets.all(12),
                  child: Text(
                    'Start camera assessment',
                    style: TextStyle(fontSize: 17),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
