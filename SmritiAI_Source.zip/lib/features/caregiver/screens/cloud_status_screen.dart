
import 'package:flutter/material.dart';

import '../../../core/backend/production_backend.dart';
import '../../../data/remote/supabase_data_service.dart';

class CloudStatusScreen extends StatelessWidget {
  const CloudStatusScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final backend = ProductionBackend.instance;
    final cloud = SupabaseDataService.instance;
    final configured = backend.configured;
    final connected = cloud.available;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Cloud & Security'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          _StatusCard(
            icon: Icons.cloud_done,
            title: 'Cloud backend',
            value: connected
                ? 'Connected'
                : configured
                    ? 'Configured but unavailable'
                    : 'Offline / demo mode',
          ),
          _StatusCard(
            icon: Icons.lock,
            title: 'Secure authentication',
            value: connected
                ? 'Supabase Auth active'
                : 'Available after cloud setup',
          ),
          _StatusCard(
            icon: Icons.verified_user,
            title: 'Patient data protection',
            value: 'Patient-scoped RLS architecture',
          ),
          _StatusCard(
            icon: Icons.photo_library,
            title: 'Memory storage',
            value: 'Private photo/audio buckets',
          ),
          _StatusCard(
            icon: Icons.assessment,
            title: 'RUDAS',
            value: 'Separate assessment history',
          ),
        ],
      ),
    );
  }
}

class _StatusCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String value;

  const _StatusCard({
    required this.icon,
    required this.title,
    required this.value,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 14),
      child: ListTile(
        leading: Icon(icon, size: 32),
        title: Text(
          title,
          style: const TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 18,
          ),
        ),
        subtitle: Padding(
          padding: const EdgeInsets.only(top: 6),
          child: Text(
            value,
            style: const TextStyle(fontSize: 16),
          ),
        ),
      ),
    );
  }
}
