
import '../../../data/remote/supabase_data_service.dart';

class PatientConnectionService {
  PatientConnectionService._();

  static final PatientConnectionService instance =
      PatientConnectionService._();

  Future<String> generatePatientCode({
    required String patientId,
  }) async {
    if (patientId.trim().isEmpty) {
      throw ArgumentError('Patient ID is required.');
    }

    return SupabaseDataService.instance
        .ensurePatientConnectionCode(patientId);
  }

  Future<String> connectUsingCode({
    required String connectionCode,
  }) async {
    final code = connectionCode.trim().toUpperCase();

    if (code.length < 6) {
      throw ArgumentError('Enter a valid patient connection code.');
    }

    return SupabaseDataService.instance
        .connectCaregiverByPatientCode(code);
  }
}
