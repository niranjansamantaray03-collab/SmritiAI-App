
import '../../../data/local/patient_connection.dart';

class ConnectedPatient {
  final String id;
  final String name;
  final String email;
  final String connectionStatus;

  const ConnectedPatient({
    required this.id,
    required this.name,
    required this.email,
    required this.connectionStatus,
  });

  bool get isConnected => connectionStatus == 'connected';
}

class CaregiverService {
  CaregiverService._();

  static final CaregiverService instance = CaregiverService._();

  final Map<String, List<ConnectedPatient>> _patients = {};

  List<ConnectedPatient> getPatients(String caregiverId) {
    final existing = _patients[caregiverId];

    if (existing != null) {
      return List.unmodifiable(existing);
    }

    // Temporary demo connection.
    // This becomes a Supabase query in the cloud build.
    final demo = const ConnectedPatient(
      id: 'p1',
      name: 'Aarav Sharma',
      email: 'patient@smriti.ai',
      connectionStatus: 'connected',
    );

    _patients[caregiverId] = [demo];

    return List.unmodifiable(_patients[caregiverId]!);
  }

  Future<void> connectPatient({
    required String caregiverId,
    required String patientId,
  }) async {
    final list = _patients.putIfAbsent(caregiverId, () => []);

    if (list.any((p) => p.id == patientId)) {
      return;
    }

    list.add(
      ConnectedPatient(
        id: patientId,
        name: 'Patient',
        email: '',
        connectionStatus: 'connected',
      ),
    );
  }

  Future<void> disconnectPatient({
    required String caregiverId,
    required String patientId,
  }) async {
    _patients[caregiverId]?.removeWhere(
      (patient) => patient.id == patientId,
    );
  }

  PatientConnection createConnectionRecord({
    required String caregiverId,
    required String patientId,
  }) {
    return PatientConnection(
      id: '${caregiverId}_$patientId',
      caregiverId: caregiverId,
      patientId: patientId,
      status: 'connected',
      connectedAt: DateTime.now(),
    );
  }
}
