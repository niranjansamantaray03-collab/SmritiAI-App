
import '../../../data/remote/supabase_data_service.dart';

class CaregiverDashboardSnapshot {
  final Map<String, dynamic>? patient;
  final List<Map<String, dynamic>> rudas;
  final List<Map<String, dynamic>> games;
  final List<Map<String, dynamic>> tasks;
  final List<Map<String, dynamic>> reminders;
  final List<Map<String, dynamic>> mood;
  final List<Map<String, dynamic>> stories;
  final int completedGameSessions;
  final bool rudasDue;

  const CaregiverDashboardSnapshot({
    required this.patient,
    required this.rudas,
    required this.games,
    required this.tasks,
    required this.reminders,
    required this.mood,
    required this.stories,
    required this.completedGameSessions,
    required this.rudasDue,
  });

  Map<String, dynamic>? get latestRudas =>
      rudas.isEmpty ? null : rudas.first;

  double get averageAccuracy {
    if (games.isEmpty) return 0;

    double total = 0;

    for (final game in games) {
      final value = game['accuracy'];

      if (value is num) {
        total += value.toDouble();
        continue;
      }

      final correct = game['correct_answers'];
      final questions = game['total_questions'];

      if (correct is num && questions is num && questions > 0) {
        total += correct.toDouble() / questions.toDouble() * 100;
      }
    }

    return total / games.length;
  }
}

class CaregiverDashboardService {
  CaregiverDashboardService._();

  static final CaregiverDashboardService instance =
      CaregiverDashboardService._();

  final _cloud = SupabaseDataService.instance;

  Future<List<Map<String, dynamic>>> getConnectedPatients() async {
    return _cloud.getConnectedPatients();
  }

  Future<CaregiverDashboardSnapshot> loadPatient(
    String patientId,
  ) async {
    final patient = await _cloud.getProfile(patientId);

    final rudas = await _safeList(
      () => _cloud.getRudasAssessments(patientId),
    );

    final games = await _safeList(
      () => _cloud.getGameSessions(patientId),
    );

    final tasks = await _safeList(
      () => _cloud.getTasks(patientId),
    );

    final reminders = await _safeList(
      () => _cloud.getReminders(patientId),
    );

    final mood = await _safeList(
      () => _cloud.getMoodEntries(patientId),
    );

    final stories = await _safeList(
      () => _cloud.getMemoryStories(patientId),
    );

    final count = await _safeCount(
      () => _cloud.getCompletedGameSessionCount(patientId),
    );

    return CaregiverDashboardSnapshot(
      patient: patient,
      rudas: rudas,
      games: games,
      tasks: tasks,
      reminders: reminders,
      mood: mood,
      stories: stories,
      completedGameSessions: count,
      rudasDue: count > 0 && count % 7 == 0,
    );
  }

  Future<List<Map<String, dynamic>>> _safeList(
    Future<List<Map<String, dynamic>>> Function() action,
  ) async {
    try {
      return await action();
    } catch (_) {
      return <Map<String, dynamic>>[];
    }
  }

  Future<int> _safeCount(
    Future<int> Function() action,
  ) async {
    try {
      return await action();
    } catch (_) {
      return 0;
    }
  }
}
