import '../../core/native/smriti_native_services.dart';
import 'voice_locale.dart';

class PatientVoiceHelper {
  PatientVoiceHelper._();

  static Future<void> speak(
    String text, {
    VoiceLocale locale = VoiceLocale.englishIndia,
  }) async {
    await SmritiNativeServices.voice.speak(
      text,
      locale: locale.localeId,
    );
  }

  static Future<void> stop() async {
    await SmritiNativeServices.voice.stop();
  }
}
