import 'package:flutter/material.dart';

import '../../core/native/smriti_native_services.dart';

class SpeechInputButton extends StatefulWidget {
  final String localeId;
  final ValueChanged<String> onText;

  const SpeechInputButton({
    super.key,
    this.localeId = 'en_IN',
    required this.onText,
  });

  @override
  State<SpeechInputButton> createState() => _SpeechInputButtonState();
}

class _SpeechInputButtonState extends State<SpeechInputButton> {
  bool listening = false;

  Future<void> toggle() async {
    if (listening) {
      await SmritiNativeServices.speech.stop();
      if (mounted) setState(() => listening = false);
      return;
    }

    final available =
        await SmritiNativeServices.speech.initialize();

    if (!available) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Speech recognition is not available on this device.',
          ),
        ),
      );
      return;
    }

    setState(() => listening = true);

    await SmritiNativeServices.speech.listen(
      localeId: widget.localeId,
      onResult: (text, isFinal) {
        if (text.trim().isNotEmpty) {
          widget.onText(text);
        }

        if (isFinal && mounted) {
          setState(() => listening = false);
        }
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return IconButton.filled(
      tooltip: listening ? 'Stop listening' : 'Speak',
      onPressed: toggle,
      icon: Icon(
        listening ? Icons.mic_off_rounded : Icons.mic_rounded,
      ),
    );
  }
}
