
import 'package:flutter/material.dart';

import '../../../core/device/smriti_device_actions.dart';
import '../voice_locale.dart';

class NativeVoiceHelpButton extends StatefulWidget {
  final String prompt;
  final VoiceLocale locale;

  const NativeVoiceHelpButton({
    super.key,
    required this.prompt,
    this.locale = VoiceLocale.english,
  });

  @override
  State<NativeVoiceHelpButton> createState() =>
      _NativeVoiceHelpButtonState();
}

class _NativeVoiceHelpButtonState
    extends State<NativeVoiceHelpButton> {

  bool listening = false;

  Future<void> _speak() async {
    await SmritiDeviceActions.instance.speak(
      widget.prompt,
      locale: widget.locale,
    );
  }

  Future<void> _listen() async {
    setState(() => listening = true);

    final result =
        await SmritiDeviceActions.instance.listen(
      locale: widget.locale,
    );

    if (!mounted) return;

    setState(() => listening = false);

    if (result != null && result.trim().isNotEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'I heard: $result',
          ),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Wrap(
      spacing: 10,
      children: [
        OutlinedButton.icon(
          onPressed: _speak,
          icon: const Icon(Icons.volume_up),
          label: const Text(
            'Hear',
            style: TextStyle(fontSize: 16),
          ),
        ),
        FilledButton.icon(
          onPressed: listening ? null : _listen,
          icon: Icon(
            listening
                ? Icons.mic
                : Icons.mic_none,
          ),
          label: Text(
            listening ? 'Listening...' : 'Speak',
            style: const TextStyle(fontSize: 16),
          ),
        ),
      ],
    );
  }
}
