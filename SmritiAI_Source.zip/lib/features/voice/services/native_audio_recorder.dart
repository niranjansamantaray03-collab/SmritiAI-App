import 'package:record/record.dart';

class NativeAudioRecorder {
  NativeAudioRecorder._();

  static final NativeAudioRecorder instance = NativeAudioRecorder._();

  final AudioRecorder _recorder = AudioRecorder();

  Future<bool> requestPermission() async {
    return _recorder.hasPermission();
  }

  Future<void> start(String path) async {
    final allowed = await requestPermission();
    if (!allowed) {
      throw StateError('Microphone permission was not granted.');
    }

    await _recorder.start(
      const RecordConfig(
        encoder: AudioEncoder.aacLc,
        bitRate: 128000,
        sampleRate: 44100,
      ),
      path: path,
    );
  }

  Future<String?> stop() async {
    return _recorder.stop();
  }

  Future<bool> isRecording() async {
    return _recorder.isRecording();
  }

  Future<void> dispose() async {
    await _recorder.dispose();
  }
}
