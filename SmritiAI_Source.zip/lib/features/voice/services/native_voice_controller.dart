
import '../voice_locale.dart';
import 'native_speech_recognition_service.dart';
import 'native_tts_service.dart';

class NativeVoiceController {
  NativeVoiceController._();

  static final NativeVoiceController instance =
      NativeVoiceController._();

  final NativeTtsService _tts = NativeTtsService.instance;
  final NativeSpeechRecognitionService _speech =
      NativeSpeechRecognitionService.instance;

  Future<void> speak(
    String text, {
    VoiceLocale locale = VoiceLocale.english,
  }) {
    return _tts.speak(
      text,
      locale: locale,
    );
  }

  Future<String?> listen({
    VoiceLocale locale = VoiceLocale.english,
  }) {
    return _speech.listen(
      locale: locale,
    );
  }

  Future<void> stop() async {
    await _tts.stop();
    await _speech.stop();
  }
}
