
import 'package:flutter_tts/flutter_tts.dart';

import '../voice_locale.dart';

class NativeTtsService {
  NativeTtsService._();

  static final NativeTtsService instance =
      NativeTtsService._();

  final FlutterTts _tts = FlutterTts();

  bool _ready = false;

  Future<void> initialize() async {
    if (_ready) return;

    await _tts.awaitSpeakCompletion(true);

    _ready = true;
  }

  String localeFor(VoiceLocale locale) {
    switch (locale) {
      case VoiceLocale.english:
        return 'en-IN';
      case VoiceLocale.hindi:
        return 'hi-IN';
      case VoiceLocale.marathi:
        return 'mr-IN';
    }
  }

  Future<void> speak(
    String text, {
    VoiceLocale locale = VoiceLocale.english,
    double rate = 0.45,
    double pitch = 1.0,
  }) async {
    await initialize();

    await _tts.setLanguage(localeFor(locale));
    await _tts.setSpeechRate(rate);
    await _tts.setPitch(pitch);
    await _tts.speak(text);
  }

  Future<void> stop() async {
    await _tts.stop();
  }
}
