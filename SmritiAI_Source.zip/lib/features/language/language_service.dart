
import '../../data/persistence/persistence_manager.dart';
import 'app_language.dart';

class LanguageService {
  LanguageService._();

  static final LanguageService instance =
      LanguageService._();

  AppLanguage _language =
      AppLanguage.english;

  AppLanguage get language =>
      _language;

  Future<void> initialize() async {
    final record =
        await PersistenceManager.instance
            .get(
      'settings',
      'language',
    );

    final value =
        record?['value'] as String?;

    if (value == null) return;

    _language =
        AppLanguage.values.firstWhere(
      (item) => item.code == value,
      orElse: () =>
          AppLanguage.english,
    );
  }

  Future<void> setLanguage(
    AppLanguage language,
  ) async {
    _language = language;

    await PersistenceManager.instance
        .save(
      'settings',
      'language',
      {
        'id': 'language',
        'value': language.code,
      },
    );
  }
}
