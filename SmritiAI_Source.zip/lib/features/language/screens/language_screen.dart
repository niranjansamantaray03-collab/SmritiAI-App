
import 'package:flutter/material.dart';

import '../app_language.dart';
import '../language_service.dart';

class LanguageScreen extends StatefulWidget {
  const LanguageScreen({super.key});

  @override
  State<LanguageScreen> createState() =>
      _LanguageScreenState();
}

class _LanguageScreenState
    extends State<LanguageScreen> {

  late AppLanguage selected;

  @override
  void initState() {
    super.initState();
    selected =
        LanguageService.instance.language;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Language / भाषा / भाषा',
          style: TextStyle(
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const Card(
            child: Padding(
              padding: EdgeInsets.all(20),
              child: Column(
                children: [
                  Icon(
                    Icons.translate,
                    size: 52,
                  ),
                  SizedBox(height: 12),
                  Text(
                    'Choose a comfortable language',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  SizedBox(height: 8),
                  Text(
                    'भाषा चुनें • भाषा निवडा',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 17),
                  ),
                ],
              ),
            ),
          ),

          const SizedBox(height: 18),

          ...AppLanguage.values.map(
            (language) => Card(
              child: RadioListTile<AppLanguage>(
                value: language,
                groupValue: selected,
                onChanged: (value) {
                  if (value == null) return;
                  setState(() {
                    selected = value;
                  });
                },
                title: Text(
                  language.nativeName,
                  style: const TextStyle(
                    fontSize: 19,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                subtitle: Text(
                  language.code == 'en'
                      ? 'English'
                      : language.code == 'hi'
                          ? 'Hindi'
                          : 'Marathi',
                ),
              ),
            ),
          ),

          const SizedBox(height: 18),

          SizedBox(
            height: 56,
            child: FilledButton.icon(
              onPressed: () async {
                await LanguageService.instance
                    .setLanguage(selected);

                if (!context.mounted) return;

                ScaffoldMessenger.of(context)
                    .showSnackBar(
                  const SnackBar(
                    content: Text(
                      'Language preference saved',
                    ),
                  ),
                );

                Navigator.pop(context);
              },
              icon: const Icon(Icons.check),
              label: const Text(
                'Save Language',
                style: TextStyle(fontSize: 17),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
