
import 'package:flutter/material.dart';

import '../app_language.dart';
import '../language_service.dart';
import '../../voice/services/voice_service.dart';
import '../../../services/audio_service.dart';

class LanguageVoiceSettingsScreen
    extends StatefulWidget {
  const LanguageVoiceSettingsScreen({
    super.key,
  });

  @override
  State<LanguageVoiceSettingsScreen> createState() =>
      _LanguageVoiceSettingsScreenState();
}

class _LanguageVoiceSettingsScreenState
    extends State<LanguageVoiceSettingsScreen> {

  late AppLanguage language;
  bool voiceOn = true;
  bool musicOn = true;

  @override
  void initState() {
    super.initState();

    language =
        LanguageService.instance.language;

    voiceOn =
        VoiceService.instance.enabled;

    musicOn =
        AudioService.instance.enabled;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Language & Voice',
          style: TextStyle(
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          const Text(
            'Language',
            style: TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.bold,
            ),
          ),

          const SizedBox(height: 10),

          ...AppLanguage.values.map(
            (item) => Card(
              child: RadioListTile<AppLanguage>(
                value: item,
                groupValue: language,
                onChanged: (value) {
                  if (value == null) return;

                  setState(() {
                    language = value;
                  });

                  LanguageService.instance
                      .setLanguage(value);
                },
                title: Text(
                  item.nativeName,
                  style: const TextStyle(
                    fontSize: 18,
                  ),
                ),
              ),
            ),
          ),

          const SizedBox(height: 18),

          const Text(
            'Voice & Music',
            style: TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.bold,
            ),
          ),

          const SizedBox(height: 10),

          Card(
            child: SwitchListTile(
              value: voiceOn,
              onChanged: (value) async {
                await VoiceService.instance
                    .setEnabled(value);

                setState(() {
                  voiceOn = value;
                });
              },
              title: const Text(
                'Spoken Guidance',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
              subtitle: const Text(
                'Allow SmritiAI to speak helpful instructions',
              ),
              secondary:
                  const Icon(Icons.record_voice_over),
            ),
          ),

          Card(
            child: SwitchListTile(
              value: musicOn,
              onChanged: (value) async {
                await AudioService.instance
                    .setEnabled(value);

                setState(() {
                  musicOn = value;
                });
              },
              title: const Text(
                'Familiar Music',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
              subtitle: const Text(
                'Allow welcome and calming music',
              ),
              secondary:
                  const Icon(Icons.music_note),
            ),
          ),

          const SizedBox(height: 20),

          FilledButton.icon(
            onPressed: () async {
              await VoiceService.instance.speak(
                language ==
                        AppLanguage.english
                    ? 'Welcome to SmritiAI'
                    : language ==
                            AppLanguage.hindi
                        ? 'स्मृति एआई में आपका स्वागत है'
                        : 'स्मृती एआयमध्ये तुमचे स्वागत आहे',
                locale: language.voiceLocale,
              );
            },
            icon: const Icon(Icons.play_arrow),
            label: const Text(
              'Test Voice',
              style: TextStyle(fontSize: 17),
            ),
          ),
        ],
      ),
    );
  }
}
