
class GameCompletionContract {
  GameCompletionContract._();

  static const int reassessmentThreshold = 7;

  static bool validScore({
    required int score,
    required int maxScore,
  }) {
    if (maxScore <= 0) return false;
    return score >= 0 && score <= maxScore;
  }

  static bool validQuestionCount({
    required int correct,
    required int total,
  }) {
    if (total < 0 || correct < 0) {
      return false;
    }

    return correct <= total;
  }
}
