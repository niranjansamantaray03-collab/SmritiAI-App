import 'dart:math';

import 'package:flutter/material.dart';

class FindObjectScreen extends StatefulWidget {
  final String patientId;

  const FindObjectScreen({
    super.key,
    required this.patientId,
  });

  @override
  State<FindObjectScreen> createState() => _FindObjectScreenState();
}

class _FindObjectScreenState extends State<FindObjectScreen> {
  final Random random = Random();

  final List<String> objects = [
    '🍎',
    '🍌',
    '🍊',
    '🍇',
    '⭐',
    '🌸',
    '❤️',
    '☀️',
    '🌙',
  ];

  String target = '';
  int score = 0;
  int round = 1;

  @override
  void initState() {
    super.initState();
    _newRound();
  }

  void _newRound() {
    target = objects[random.nextInt(objects.length)];
    setState(() {});
  }

  void _select(String item) {
    if (item == target) {
      score += 10;
    }

    if (round >= 10) {
      _finish();
      return;
    }

    round++;
    _newRound();
  }

  void _finish() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        title: const Text('Game complete 🎉'),
        content: Text(
          'Your score is $score / 100',
          style: const TextStyle(fontSize: 20),
        ),
        actions: [
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              Navigator.pop(context);
            },
            child: const Text('Finish'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Find the Object'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            Text(
              'Round $round / 10',
              style: const TextStyle(fontSize: 20),
            ),
            const SizedBox(height: 20),
            const Text(
              'Find:',
              style: TextStyle(fontSize: 25),
            ),
            Text(
              target,
              style: const TextStyle(fontSize: 70),
            ),
            const SizedBox(height: 20),
            Expanded(
              child: GridView.count(
                crossAxisCount: 3,
                crossAxisSpacing: 12,
                mainAxisSpacing: 12,
                children: objects.map((item) {
                  return ElevatedButton(
                    onPressed: () => _select(item),
                    child: Text(
                      item,
                      style: const TextStyle(fontSize: 45),
                    ),
                  );
                }).toList(),
              ),
            ),
            Text(
              'Score: $score',
              style: const TextStyle(fontSize: 20),
            ),
          ],
        ),
      ),
    );
  }
}
