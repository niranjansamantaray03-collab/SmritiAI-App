import 'dart:async';

import 'package:flutter/material.dart';

import '../game_engine.dart';

class PatternSequenceScreen extends StatefulWidget {
  final String patientId;

  const PatternSequenceScreen({
    super.key,
    required this.patientId,
  });

  @override
  State<PatternSequenceScreen> createState() =>
      _PatternSequenceScreenState();
}

class _PatternSequenceScreenState
    extends State<PatternSequenceScreen> {
  List<int> sequence = [];
  List<int> answer = [];
  bool showing = false;
  int round = 1;
  int score = 0;

  @override
  void initState() {
    super.initState();
    _startRound();
  }

  Future<void> _startRound() async {
    sequence = GameEngine.generateNumberSequence(
      round + 2,
    );

    answer.clear();

    setState(() {
      showing = true;
    });

    await Future.delayed(
      Duration(milliseconds: 900 + sequence.length * 350),
    );

    if (!mounted) return;

    setState(() {
      showing = false;
    });
  }

  void _select(int number) {
    if (showing) return;

    setState(() {
      answer.add(number);
    });

    final position = answer.length - 1;

    if (answer[position] != sequence[position]) {
      _finish(false);
      return;
    }

    if (answer.length == sequence.length) {
      score += sequence.length * 10;

      if (round >= 5) {
        _finish(true);
      } else {
        round++;
        _startRound();
      }
    }
  }

  void _finish(bool completed) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        title: Text(completed ? 'Excellent! 🎉' : 'Good try!'),
        content: Text(
          'Rounds completed: ${round - (completed ? 0 : 1)}\n'
          'Score: $score',
          style: const TextStyle(fontSize: 19),
        ),
        actions: [
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              Navigator.pop(context);
            },
            child: const Text('Finish'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final buttons = [1, 2, 3, 4, 5, 6, 7, 8, 9];

    return Scaffold(
      appBar: AppBar(
        title: const Text('Pattern Sequence'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(22),
        child: Column(
          children: [
            Text(
              'Round $round of 5',
              style: const TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 18),
            Text(
              showing
                  ? sequence.join('   ')
                  : 'Now repeat the sequence',
              textAlign: TextAlign.center,
              style: const TextStyle(
                fontSize: 30,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 30),
            Expanded(
              child: GridView.count(
                crossAxisCount: 3,
                crossAxisSpacing: 12,
                mainAxisSpacing: 12,
                children: buttons.map((number) {
                  return ElevatedButton(
                    onPressed: showing
                        ? null
                        : () => _select(number),
                    child: Text(
                      '$number',
                      style: const TextStyle(fontSize: 28),
                    ),
                  );
                }).toList(),
              ),
            ),
            Text(
              'Score: $score',
              style: const TextStyle(fontSize: 20),
            ),
          ],
        ),
      ),
    );
  }
}
