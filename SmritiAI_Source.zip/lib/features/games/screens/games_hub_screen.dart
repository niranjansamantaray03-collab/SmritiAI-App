import 'package:flutter/material.dart';

import 'find_object_screen.dart';
import 'memory_match_screen.dart';
import 'number_memory_screen.dart';
import 'pattern_sequence_screen.dart';

class GamesHubScreen extends StatelessWidget {
  final String patientId;

  const GamesHubScreen({
    super.key,
    required this.patientId,
  });

  @override
  Widget build(BuildContext context) {
    final games = [
      (
        '🧩',
        'Memory Match',
        'Find matching pairs',
        () => MemoryMatchScreen(patientId: patientId),
      ),
      (
        '🔢',
        'Pattern Sequence',
        'Remember the sequence',
        () => PatternSequenceScreen(patientId: patientId),
      ),
      (
        '🔎',
        'Find the Object',
        'Find the requested object',
        () => FindObjectScreen(patientId: patientId),
      ),
      (
        '🔢',
        'Number Memory',
        'Remember numbers',
        () => NumberMemoryScreen(patientId: patientId),
      ),
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text('Cognitive Games'),
      ),
      body: ListView.builder(
        padding: const EdgeInsets.all(18),
        itemCount: games.length,
        itemBuilder: (_, index) {
          final game = games[index];

          return Card(
            child: InkWell(
              borderRadius: BorderRadius.circular(20),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => game.$4(),
                  ),
                );
              },
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Row(
                  children: [
                    Text(
                      game.$1,
                      style: const TextStyle(fontSize: 45),
                    ),
                    const SizedBox(width: 18),
                    Expanded(
                      child: Column(
                        crossAxisAlignment:
                            CrossAxisAlignment.start,
                        children: [
                          Text(
                            game.$2,
                            style: const TextStyle(
                              fontSize: 21,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const SizedBox(height: 5),
                          Text(
                            game.$3,
                            style: const TextStyle(fontSize: 16),
                          ),
                        ],
                      ),
                    ),
                    const Icon(
                      Icons.arrow_forward_ios_rounded,
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}
