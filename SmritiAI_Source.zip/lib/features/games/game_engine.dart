
import '../models/game_history_entry.dart';
import '../services/game_history_service.dart';
import '../../rudas/services/rudas_service.dart';

class GameSession {
  final String id;
  final String patientId;
  final String gameId;
  final String gameName;
  final DateTime startedAt;

  int correctAnswers;
  int totalQuestions;
  int score;

  DateTime? completedAt;

  GameSession({
    required this.id,
    required this.patientId,
    required this.gameId,
    required this.gameName,
    required this.startedAt,
    this.correctAnswers = 0,
    this.totalQuestions = 0,
    this.score = 0,
  });

  double get accuracy {
    if (totalQuestions == 0) {
      return 0;
    }

    return correctAnswers /
        totalQuestions;
  }

  int get durationSeconds {
    final end =
        completedAt ?? DateTime.now();

    return end
        .difference(startedAt)
        .inSeconds;
  }

  void answer({
    required bool correct,
    int points = 1,
  }) {
    totalQuestions++;

    if (correct) {
      correctAnswers++;
      score += points;
    }
  }

  Future<GameHistoryEntry>
      complete() async {
    completedAt = DateTime.now();

    final entry = GameHistoryEntry(
      id: id,
      patientId: patientId,
      gameId: gameId,
      gameName: gameName,
      playedAt: startedAt,
      score: score,
      maxScore:
          totalQuestions,
      durationSeconds:
          durationSeconds,
      correctAnswers:
          correctAnswers,
      totalQuestions:
          totalQuestions,
    );

    await GameHistoryService.instance
        .recordCompletedGame(entry);

    // IMPORTANT:
    // Game performance is NOT converted into RUDAS.
    //
    // This only increments the completed-game-session
    // checkpoint counter.
    await RudasService.instance
        .recordCompletedGameSession(
      patientId,
    );

    return entry;
  }
}

class GameEngine {
  GameEngine._();

  static final GameEngine instance =
      GameEngine._();

  GameSession start({
    required String patientId,
    required String gameId,
    required String gameName,
  }) {
    return GameSession(
      id:
          'game_${DateTime.now().microsecondsSinceEpoch}',
      patientId: patientId,
      gameId: gameId,
      gameName: gameName,
      startedAt: DateTime.now(),
    );
  }
}
