
import 'models/game_definition.dart';

class GameCatalog {
  GameCatalog._();

  static const List<GameDefinition> games = [
    GameDefinition(
      id: 'memory_match',
      name: 'Memory Match',
      description:
          'Find matching pairs and exercise visual memory.',
      icon: '🧠',
      defaultQuestions: 8,
    ),
    GameDefinition(
      id: 'pattern_sequence',
      name: 'Pattern Sequence',
      description:
          'Remember the sequence and select what comes next.',
      icon: '🔢',
      defaultQuestions: 8,
    ),
    GameDefinition(
      id: 'find_object',
      name: 'Find the Object',
      description:
          'Find the requested object among simple choices.',
      icon: '🔎',
      defaultQuestions: 8,
    ),
    GameDefinition(
      id: 'number_memory',
      name: 'Number Memory',
      description:
          'Remember a short number sequence.',
      icon: '🔢',
      defaultQuestions: 8,
    ),
    GameDefinition(
      id: 'pattern_match',
      name: 'Pattern Match',
      description:
          'Match the visual pattern correctly.',
      icon: '🧩',
      defaultQuestions: 8,
    ),
    GameDefinition(
      id: 'find_difference',
      name: 'Find the Difference',
      description:
          'Look carefully and identify the different item.',
      icon: '👀',
      defaultQuestions: 8,
    ),
  ];

  static GameDefinition? byId(
    String id,
  ) {
    for (final game in games) {
      if (game.id == id) return game;
    }

    return null;
  }
}
